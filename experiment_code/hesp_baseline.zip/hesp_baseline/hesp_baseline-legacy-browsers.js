﻿/********************** 
 * Hesp_Baseline Test *
 **********************/


// store info about the experiment session:
let expName = 'hesp_baseline';  // from the Builder filename that created this script
let expInfo = {'Azonosító': 'nincsen', 'Melyik évben születtél?': '2000', 'Mi a nemed?': 'nő', 'Tanultál nyelvészetet?': 'nem'};

// Start code blocks for 'Before Experiment'
// init psychoJS:
const psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: true,
  color: new util.Color('black'),
  units: 'norm',
  waitBlanking: true
});
// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); }, flowScheduler, dialogCancelScheduler);

// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);
flowScheduler.add(intro_1RoutineBegin());
flowScheduler.add(intro_1RoutineEachFrame());
flowScheduler.add(intro_1RoutineEnd());
flowScheduler.add(intro_2RoutineBegin());
flowScheduler.add(intro_2RoutineEachFrame());
flowScheduler.add(intro_2RoutineEnd());
flowScheduler.add(practice_1RoutineBegin());
flowScheduler.add(practice_1RoutineEachFrame());
flowScheduler.add(practice_1RoutineEnd());
flowScheduler.add(intro_3RoutineBegin());
flowScheduler.add(intro_3RoutineEachFrame());
flowScheduler.add(intro_3RoutineEnd());
flowScheduler.add(practice_2RoutineBegin());
flowScheduler.add(practice_2RoutineEachFrame());
flowScheduler.add(practice_2RoutineEnd());
flowScheduler.add(intro_4RoutineBegin());
flowScheduler.add(intro_4RoutineEachFrame());
flowScheduler.add(intro_4RoutineEnd());
flowScheduler.add(practice_3RoutineBegin());
flowScheduler.add(practice_3RoutineEachFrame());
flowScheduler.add(practice_3RoutineEnd());
flowScheduler.add(intro_5RoutineBegin());
flowScheduler.add(intro_5RoutineEachFrame());
flowScheduler.add(intro_5RoutineEnd());
const withinBlockLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(withinBlockLoopBegin(withinBlockLoopScheduler));
flowScheduler.add(withinBlockLoopScheduler);
flowScheduler.add(withinBlockLoopEnd);
flowScheduler.add(outroRoutineBegin());
flowScheduler.add(outroRoutineEachFrame());
flowScheduler.add(outroRoutineEnd());
flowScheduler.add(quitPsychoJS, '', true);

// quit if user presses Cancel in dialog box:
dialogCancelScheduler.add(quitPsychoJS, '', false);

psychoJS.start({
  expName: expName,
  expInfo: expInfo,
  resources: [
    {'name': 'list3.csv', 'path': 'list3.csv'},
    {'name': 'list1.csv', 'path': 'list1.csv'},
    {'name': 'list2.csv', 'path': 'list2.csv'}
  ]
});

psychoJS.experimentLogger.setLevel(core.Logger.ServerLevel.WARNING);


var frameDur;
async function updateInfo() {
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '2021.2.3';
  expInfo['OS'] = window.navigator.platform;

  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0 / Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0 / 60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  
  return Scheduler.Event.NEXT;
}


var intro_1Clock;
var intro1;
var key;
var intro_2Clock;
var intro1_2;
var key_2;
var practice_1Clock;
var prompt_text_2;
var target_text_2;
var button;
var buttontext;
var button_3;
var buttontext_3;
var keyboard_input_2;
var intro_3Clock;
var intro1_3;
var key_3;
var practice_2Clock;
var prompt_text_3;
var target_text_3;
var button_4;
var buttontext_4;
var button_5;
var buttontext_5;
var keyboard_input_3;
var intro_4Clock;
var intro1_4;
var key_4;
var practice_3Clock;
var prompt_text_4;
var target_text_4;
var button_6;
var buttontext_6;
var button_7;
var buttontext_7;
var keyboard_input_4;
var intro_5Clock;
var intro_5b;
var key_5;
var wordClock;
var fileList;
var condsFile;
var prompt_text;
var target_text;
var button_1;
var buttontext_1;
var button_2;
var buttontext_2;
var keyboard_input;
var outroClock;
var text;
var globalClock;
var routineTimer;
async function experimentInit() {
  // Initialize components for Routine "intro_1"
  intro_1Clock = new util.Clock();
  intro1 = new visual.TextStim({
    win: psychoJS.window,
    name: 'intro1',
    text: 'Ebben a játékban szavakat kell toldalékolni.\nMinden körben mutatunk majd egy példamondatot, amiben lesz egy szó.\n\nAlatta jön egy második mondat, ezt a mondatot neked kell majd befejezni, ugyanezzel a szóval.\n\nMinden mondathoz adunk két lehetőséget, ezeket balra és jobbra látod majd.\n\nA játék kb. negyedóráig tart. Nyomj egy space-t a folytatáshoz.\n',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.075,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('white'),  opacity: undefined,
    depth: 0.0 
  });
  
  key = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "intro_2"
  intro_2Clock = new util.Clock();
  intro1_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'intro1_2',
    text: 'A két lehetőség között úgy választhatsz, hogy a nyilakat használod a billentyűzeten.\n\nA "bal" nyíl a baloldali lehetőséget, a "jobb" nyíl a jobboldali lehetőséget választja ki.\n\nLássunk egy példát. Nyomj egy space-t a folytatáshoz.',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.075,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('white'),  opacity: undefined,
    depth: 0.0 
  });
  
  key_2 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "practice_1"
  practice_1Clock = new util.Clock();
  prompt_text_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'prompt_text_2',
    text: 'Itt egy példa: "János nagyon sokat sétál."',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0.6], height: 0.075,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  target_text_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'target_text_2',
    text: 'És ezt a mondatot kell befejezni: "Tegnap is nagyon sokat..."',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0.3], height: 0.075,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('white'),  opacity: undefined,
    depth: -1.0 
  });
  
  button = new visual.Rect ({
    win: psychoJS.window, name: 'button', 
    width: [0.3, 0.25][0], height: [0.3, 0.25][1],
    ori: 0.0, pos: [(- 0.25), (- 0.1)],
    lineWidth: 1.0, lineColor: new util.Color('white'),
    fillColor: new util.Color('white'),
    opacity: undefined, depth: -2, interpolate: true,
  });
  
  buttontext = new visual.TextStim({
    win: psychoJS.window,
    name: 'buttontext',
    text: 'sétálja',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.075,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('black'),  opacity: undefined,
    depth: -3.0 
  });
  
  button_3 = new visual.Rect ({
    win: psychoJS.window, name: 'button_3', 
    width: [0.3, 0.25][0], height: [0.3, 0.25][1],
    ori: 0.0, pos: [0.25, (- 0.1)],
    lineWidth: 1.0, lineColor: new util.Color('white'),
    fillColor: new util.Color('white'),
    opacity: undefined, depth: -4, interpolate: true,
  });
  
  buttontext_3 = new visual.TextStim({
    win: psychoJS.window,
    name: 'buttontext_3',
    text: 'sétált',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.075,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('black'),  opacity: undefined,
    depth: -5.0 
  });
  
  keyboard_input_2 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "intro_3"
  intro_3Clock = new util.Clock();
  intro1_3 = new visual.TextStim({
    win: psychoJS.window,
    name: 'intro1_3',
    text: 'Ebben a példában volt egy jó válasz ("János tegnap is sokat sétált") és egy nem valami jó válasz ("János tegnap is sokat sétálja").\n\nNézzünk egy olyan példát, ahol nincs igazán jó válasz, azt a lehetőséget választhatod, ami neked jobban hangzik. Ehhez most is a billentyűzeten a bal és a jobb nyílt tudod használni.\n\nNyomj egy space-t a folytatáshoz.',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.075,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('white'),  opacity: undefined,
    depth: 0.0 
  });
  
  key_3 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "practice_2"
  practice_2Clock = new util.Clock();
  prompt_text_3 = new visual.TextStim({
    win: psychoJS.window,
    name: 'prompt_text_3',
    text: '"János már nem haragszik."',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0.6], height: 0.075,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  target_text_3 = new visual.TextStim({
    win: psychoJS.window,
    name: 'target_text_3',
    text: '"Arra kérlek, te se..."',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0.3], height: 0.075,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('white'),  opacity: undefined,
    depth: -1.0 
  });
  
  button_4 = new visual.Rect ({
    win: psychoJS.window, name: 'button_4', 
    width: [0.3, 0.25][0], height: [0.3, 0.25][1],
    ori: 0.0, pos: [(- 0.25), (- 0.1)],
    lineWidth: 1.0, lineColor: new util.Color('white'),
    fillColor: new util.Color('white'),
    opacity: undefined, depth: -2, interpolate: true,
  });
  
  buttontext_4 = new visual.TextStim({
    win: psychoJS.window,
    name: 'buttontext_4',
    text: 'haragudj',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.075,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('black'),  opacity: undefined,
    depth: -3.0 
  });
  
  button_5 = new visual.Rect ({
    win: psychoJS.window, name: 'button_5', 
    width: [0.3, 0.25][0], height: [0.3, 0.25][1],
    ori: 0.0, pos: [0.25, (- 0.1)],
    lineWidth: 1.0, lineColor: new util.Color('white'),
    fillColor: new util.Color('white'),
    opacity: undefined, depth: -4, interpolate: true,
  });
  
  buttontext_5 = new visual.TextStim({
    win: psychoJS.window,
    name: 'buttontext_5',
    text: 'haragudjál',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.075,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('black'),  opacity: undefined,
    depth: -5.0 
  });
  
  keyboard_input_3 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "intro_4"
  intro_4Clock = new util.Clock();
  intro1_4 = new visual.TextStim({
    win: psychoJS.window,
    name: 'intro1_4',
    text: 'Ebben a példában mind a két válasz jó volt, de lehet, hogy az egyik neked jobban hangzott.\n\nÚgy is lehet ilyet játszani, hogy ha nem is tudod pontosan, mit jelent maga a szó. Nézzünk meg egy példát.\n\nNyomj egy space-t a folytatáshoz.',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.075,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('white'),  opacity: undefined,
    depth: 0.0 
  });
  
  key_4 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "practice_3"
  practice_3Clock = new util.Clock();
  prompt_text_4 = new visual.TextStim({
    win: psychoJS.window,
    name: 'prompt_text_4',
    text: 'János szívesen szinklasztikulál.',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0.6], height: 0.075,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  target_text_4 = new visual.TextStim({
    win: psychoJS.window,
    name: 'target_text_4',
    text: 'Arra kérlek, te is gyakran...',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0.3], height: 0.075,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('white'),  opacity: undefined,
    depth: -1.0 
  });
  
  button_6 = new visual.Rect ({
    win: psychoJS.window, name: 'button_6', 
    width: [0.3, 0.25][0], height: [0.3, 0.25][1],
    ori: 0.0, pos: [(- 0.25), (- 0.1)],
    lineWidth: 1.0, lineColor: new util.Color('white'),
    fillColor: new util.Color('white'),
    opacity: undefined, depth: -2, interpolate: true,
  });
  
  buttontext_6 = new visual.TextStim({
    win: psychoJS.window,
    name: 'buttontext_6',
    text: 'szinklasztikulálj',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.06,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('black'),  opacity: undefined,
    depth: -3.0 
  });
  
  button_7 = new visual.Rect ({
    win: psychoJS.window, name: 'button_7', 
    width: [0.3, 0.25][0], height: [0.3, 0.25][1],
    ori: 0.0, pos: [0.25, (- 0.1)],
    lineWidth: 1.0, lineColor: new util.Color('white'),
    fillColor: new util.Color('white'),
    opacity: undefined, depth: -4, interpolate: true,
  });
  
  buttontext_7 = new visual.TextStim({
    win: psychoJS.window,
    name: 'buttontext_7',
    text: 'szinklasztikuláljál',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.06,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('black'),  opacity: undefined,
    depth: -5.0 
  });
  
  keyboard_input_4 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "intro_5"
  intro_5Clock = new util.Clock();
  intro_5b = new visual.TextStim({
    win: psychoJS.window,
    name: 'intro_5b',
    text: 'Ha az ember nem ismeri a "szinklasztikulál" szót, akkor is tudja toldalékolni egy ilyen példamondatban. \n\nMost kezdődik a játék. A következő magyar szavakat sem biztos, hogy ismered, de próbáld meg eldönteni, melyik lehetőség hangzik jobban.\n\nFigyelj majd a mondatokra, mert többféle toldalékkal is találkozni fogsz!\n\nMinden mondatnál a "bal" nyíl a baloldali lehetőséget, a "jobb" nyíl a jobboldali lehetőséget választja ki.\n\nNyomj egy space-t a kezdéshez.',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.075,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('white'),  opacity: undefined,
    depth: 0.0 
  });
  
  key_5 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "word"
  wordClock = new util.Clock();
  // Automatically exit if the experiment is running on a mobile device
  if( /Android|webOS|iPhone|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
    quitPsychoJS('Sajnos a játékot csak számítógépen vagy laptopon lehet játszani.', false)
  }
  
  function randomChoice(arr) {
      return arr[Math.floor(arr.length * Math.random())];
  }
  
  fileList = ["list1.csv", "list2.csv", "list3.csv"];
  condsFile = randomChoice(fileList);
  psychoJS.experiment.addData("my_list", condsFile);
  prompt_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'prompt_text',
    text: '',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0.6], height: 0.075,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  target_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'target_text',
    text: '',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0.3], height: 0.075,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('white'),  opacity: undefined,
    depth: -2.0 
  });
  
  button_1 = new visual.Rect ({
    win: psychoJS.window, name: 'button_1', 
    width: [0.3, 0.25][0], height: [0.3, 0.25][1],
    ori: 0.0, pos: [(- 0.25), (- 0.1)],
    lineWidth: 1.0, lineColor: new util.Color('white'),
    fillColor: new util.Color('white'),
    opacity: undefined, depth: -3, interpolate: true,
  });
  
  buttontext_1 = new visual.TextStim({
    win: psychoJS.window,
    name: 'buttontext_1',
    text: '',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.075,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('black'),  opacity: undefined,
    depth: -4.0 
  });
  
  button_2 = new visual.Rect ({
    win: psychoJS.window, name: 'button_2', 
    width: [0.3, 0.25][0], height: [0.3, 0.25][1],
    ori: 0.0, pos: [0.25, (- 0.1)],
    lineWidth: 1.0, lineColor: new util.Color('white'),
    fillColor: new util.Color('white'),
    opacity: undefined, depth: -5, interpolate: true,
  });
  
  buttontext_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'buttontext_2',
    text: '',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.075,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('black'),  opacity: undefined,
    depth: -6.0 
  });
  
  keyboard_input = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "outro"
  outroClock = new util.Clock();
  text = new visual.TextStim({
    win: psychoJS.window,
    name: 'text',
    text: 'Köszönjük szépen a részvételt!',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.08,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('white'),  opacity: undefined,
    depth: 0.0 
  });
  
  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine
  
  return Scheduler.Event.NEXT;
}


var t;
var frameN;
var continueRoutine;
var _key_allKeys;
var intro_1Components;
function intro_1RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'intro_1'-------
    t = 0;
    intro_1Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    key.keys = undefined;
    key.rt = undefined;
    _key_allKeys = [];
    // keep track of which components have finished
    intro_1Components = [];
    intro_1Components.push(intro1);
    intro_1Components.push(key);
    
    intro_1Components.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function intro_1RoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'intro_1'-------
    // get current time
    t = intro_1Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *intro1* updates
    if (t >= 0.5 && intro1.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      intro1.tStart = t;  // (not accounting for frame time here)
      intro1.frameNStart = frameN;  // exact frame index
      
      intro1.setAutoDraw(true);
    }

    
    // *key* updates
    if (t >= 0.5 && key.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key.tStart = t;  // (not accounting for frame time here)
      key.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key.clearEvents(); });
    }

    if (key.status === PsychoJS.Status.STARTED) {
      let theseKeys = key.getKeys({keyList: ['space'], waitRelease: false});
      _key_allKeys = _key_allKeys.concat(theseKeys);
      if (_key_allKeys.length > 0) {
        key.keys = _key_allKeys[_key_allKeys.length - 1].name;  // just the last key pressed
        key.rt = _key_allKeys[_key_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    intro_1Components.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function intro_1RoutineEnd() {
  return async function () {
    //------Ending Routine 'intro_1'-------
    intro_1Components.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('key.keys', key.keys);
    if (typeof key.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('key.rt', key.rt);
        routineTimer.reset();
        }
    
    key.stop();
    // the Routine "intro_1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _key_2_allKeys;
var intro_2Components;
function intro_2RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'intro_2'-------
    t = 0;
    intro_2Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    key_2.keys = undefined;
    key_2.rt = undefined;
    _key_2_allKeys = [];
    // keep track of which components have finished
    intro_2Components = [];
    intro_2Components.push(intro1_2);
    intro_2Components.push(key_2);
    
    intro_2Components.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function intro_2RoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'intro_2'-------
    // get current time
    t = intro_2Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *intro1_2* updates
    if (t >= 0.5 && intro1_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      intro1_2.tStart = t;  // (not accounting for frame time here)
      intro1_2.frameNStart = frameN;  // exact frame index
      
      intro1_2.setAutoDraw(true);
    }

    
    // *key_2* updates
    if (t >= 0.5 && key_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_2.tStart = t;  // (not accounting for frame time here)
      key_2.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_2.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_2.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_2.clearEvents(); });
    }

    if (key_2.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_2.getKeys({keyList: ['space'], waitRelease: false});
      _key_2_allKeys = _key_2_allKeys.concat(theseKeys);
      if (_key_2_allKeys.length > 0) {
        key_2.keys = _key_2_allKeys[_key_2_allKeys.length - 1].name;  // just the last key pressed
        key_2.rt = _key_2_allKeys[_key_2_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    intro_2Components.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function intro_2RoutineEnd() {
  return async function () {
    //------Ending Routine 'intro_2'-------
    intro_2Components.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('key_2.keys', key_2.keys);
    if (typeof key_2.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('key_2.rt', key_2.rt);
        routineTimer.reset();
        }
    
    key_2.stop();
    // the Routine "intro_2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _keyboard_input_2_allKeys;
var practice_1Components;
function practice_1RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'practice_1'-------
    t = 0;
    practice_1Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    prompt_text_2.setColor(new util.Color([1, 1, 1]));
    buttontext.setPos([(- 0.25), (- 0.1)]);
    buttontext_3.setPos([0.25, (- 0.1)]);
    keyboard_input_2.keys = undefined;
    keyboard_input_2.rt = undefined;
    _keyboard_input_2_allKeys = [];
    // keep track of which components have finished
    practice_1Components = [];
    practice_1Components.push(prompt_text_2);
    practice_1Components.push(target_text_2);
    practice_1Components.push(button);
    practice_1Components.push(buttontext);
    practice_1Components.push(button_3);
    practice_1Components.push(buttontext_3);
    practice_1Components.push(keyboard_input_2);
    
    practice_1Components.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function practice_1RoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'practice_1'-------
    // get current time
    t = practice_1Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *prompt_text_2* updates
    if (t >= 0.5 && prompt_text_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      prompt_text_2.tStart = t;  // (not accounting for frame time here)
      prompt_text_2.frameNStart = frameN;  // exact frame index
      
      prompt_text_2.setAutoDraw(true);
    }

    
    // *target_text_2* updates
    if (t >= 0.5 && target_text_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      target_text_2.tStart = t;  // (not accounting for frame time here)
      target_text_2.frameNStart = frameN;  // exact frame index
      
      target_text_2.setAutoDraw(true);
    }

    
    // *button* updates
    if (t >= 0.5 && button.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      button.tStart = t;  // (not accounting for frame time here)
      button.frameNStart = frameN;  // exact frame index
      
      button.setAutoDraw(true);
    }

    
    // *buttontext* updates
    if (t >= 0.5 && buttontext.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      buttontext.tStart = t;  // (not accounting for frame time here)
      buttontext.frameNStart = frameN;  // exact frame index
      
      buttontext.setAutoDraw(true);
    }

    
    // *button_3* updates
    if (t >= 0.5 && button_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      button_3.tStart = t;  // (not accounting for frame time here)
      button_3.frameNStart = frameN;  // exact frame index
      
      button_3.setAutoDraw(true);
    }

    
    // *buttontext_3* updates
    if (t >= 0.5 && buttontext_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      buttontext_3.tStart = t;  // (not accounting for frame time here)
      buttontext_3.frameNStart = frameN;  // exact frame index
      
      buttontext_3.setAutoDraw(true);
    }

    
    // *keyboard_input_2* updates
    if (t >= 0.5 && keyboard_input_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      keyboard_input_2.tStart = t;  // (not accounting for frame time here)
      keyboard_input_2.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { keyboard_input_2.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { keyboard_input_2.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { keyboard_input_2.clearEvents(); });
    }

    if (keyboard_input_2.status === PsychoJS.Status.STARTED) {
      let theseKeys = keyboard_input_2.getKeys({keyList: ['left', 'right'], waitRelease: false});
      _keyboard_input_2_allKeys = _keyboard_input_2_allKeys.concat(theseKeys);
      if (_keyboard_input_2_allKeys.length > 0) {
        keyboard_input_2.keys = _keyboard_input_2_allKeys[_keyboard_input_2_allKeys.length - 1].name;  // just the last key pressed
        keyboard_input_2.rt = _keyboard_input_2_allKeys[_keyboard_input_2_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    practice_1Components.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function practice_1RoutineEnd() {
  return async function () {
    //------Ending Routine 'practice_1'-------
    practice_1Components.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('keyboard_input_2.keys', keyboard_input_2.keys);
    if (typeof keyboard_input_2.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('keyboard_input_2.rt', keyboard_input_2.rt);
        routineTimer.reset();
        }
    
    keyboard_input_2.stop();
    // the Routine "practice_1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _key_3_allKeys;
var intro_3Components;
function intro_3RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'intro_3'-------
    t = 0;
    intro_3Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    key_3.keys = undefined;
    key_3.rt = undefined;
    _key_3_allKeys = [];
    // keep track of which components have finished
    intro_3Components = [];
    intro_3Components.push(intro1_3);
    intro_3Components.push(key_3);
    
    intro_3Components.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function intro_3RoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'intro_3'-------
    // get current time
    t = intro_3Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *intro1_3* updates
    if (t >= 0.5 && intro1_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      intro1_3.tStart = t;  // (not accounting for frame time here)
      intro1_3.frameNStart = frameN;  // exact frame index
      
      intro1_3.setAutoDraw(true);
    }

    
    // *key_3* updates
    if (t >= 0.5 && key_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_3.tStart = t;  // (not accounting for frame time here)
      key_3.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_3.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_3.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_3.clearEvents(); });
    }

    if (key_3.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_3.getKeys({keyList: ['space'], waitRelease: false});
      _key_3_allKeys = _key_3_allKeys.concat(theseKeys);
      if (_key_3_allKeys.length > 0) {
        key_3.keys = _key_3_allKeys[_key_3_allKeys.length - 1].name;  // just the last key pressed
        key_3.rt = _key_3_allKeys[_key_3_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    intro_3Components.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function intro_3RoutineEnd() {
  return async function () {
    //------Ending Routine 'intro_3'-------
    intro_3Components.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('key_3.keys', key_3.keys);
    if (typeof key_3.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('key_3.rt', key_3.rt);
        routineTimer.reset();
        }
    
    key_3.stop();
    // the Routine "intro_3" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _keyboard_input_3_allKeys;
var practice_2Components;
function practice_2RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'practice_2'-------
    t = 0;
    practice_2Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    prompt_text_3.setColor(new util.Color([1, 1, 1]));
    buttontext_4.setPos([(- 0.25), (- 0.1)]);
    buttontext_5.setPos([0.25, (- 0.1)]);
    keyboard_input_3.keys = undefined;
    keyboard_input_3.rt = undefined;
    _keyboard_input_3_allKeys = [];
    // keep track of which components have finished
    practice_2Components = [];
    practice_2Components.push(prompt_text_3);
    practice_2Components.push(target_text_3);
    practice_2Components.push(button_4);
    practice_2Components.push(buttontext_4);
    practice_2Components.push(button_5);
    practice_2Components.push(buttontext_5);
    practice_2Components.push(keyboard_input_3);
    
    practice_2Components.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function practice_2RoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'practice_2'-------
    // get current time
    t = practice_2Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *prompt_text_3* updates
    if (t >= 0.5 && prompt_text_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      prompt_text_3.tStart = t;  // (not accounting for frame time here)
      prompt_text_3.frameNStart = frameN;  // exact frame index
      
      prompt_text_3.setAutoDraw(true);
    }

    
    // *target_text_3* updates
    if (t >= 0.5 && target_text_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      target_text_3.tStart = t;  // (not accounting for frame time here)
      target_text_3.frameNStart = frameN;  // exact frame index
      
      target_text_3.setAutoDraw(true);
    }

    
    // *button_4* updates
    if (t >= 0.5 && button_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      button_4.tStart = t;  // (not accounting for frame time here)
      button_4.frameNStart = frameN;  // exact frame index
      
      button_4.setAutoDraw(true);
    }

    
    // *buttontext_4* updates
    if (t >= 0.5 && buttontext_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      buttontext_4.tStart = t;  // (not accounting for frame time here)
      buttontext_4.frameNStart = frameN;  // exact frame index
      
      buttontext_4.setAutoDraw(true);
    }

    
    // *button_5* updates
    if (t >= 0.5 && button_5.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      button_5.tStart = t;  // (not accounting for frame time here)
      button_5.frameNStart = frameN;  // exact frame index
      
      button_5.setAutoDraw(true);
    }

    
    // *buttontext_5* updates
    if (t >= 0.5 && buttontext_5.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      buttontext_5.tStart = t;  // (not accounting for frame time here)
      buttontext_5.frameNStart = frameN;  // exact frame index
      
      buttontext_5.setAutoDraw(true);
    }

    
    // *keyboard_input_3* updates
    if (t >= 0.5 && keyboard_input_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      keyboard_input_3.tStart = t;  // (not accounting for frame time here)
      keyboard_input_3.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { keyboard_input_3.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { keyboard_input_3.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { keyboard_input_3.clearEvents(); });
    }

    if (keyboard_input_3.status === PsychoJS.Status.STARTED) {
      let theseKeys = keyboard_input_3.getKeys({keyList: ['left', 'right'], waitRelease: false});
      _keyboard_input_3_allKeys = _keyboard_input_3_allKeys.concat(theseKeys);
      if (_keyboard_input_3_allKeys.length > 0) {
        keyboard_input_3.keys = _keyboard_input_3_allKeys[_keyboard_input_3_allKeys.length - 1].name;  // just the last key pressed
        keyboard_input_3.rt = _keyboard_input_3_allKeys[_keyboard_input_3_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    practice_2Components.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function practice_2RoutineEnd() {
  return async function () {
    //------Ending Routine 'practice_2'-------
    practice_2Components.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('keyboard_input_3.keys', keyboard_input_3.keys);
    if (typeof keyboard_input_3.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('keyboard_input_3.rt', keyboard_input_3.rt);
        routineTimer.reset();
        }
    
    keyboard_input_3.stop();
    // the Routine "practice_2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _key_4_allKeys;
var intro_4Components;
function intro_4RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'intro_4'-------
    t = 0;
    intro_4Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    key_4.keys = undefined;
    key_4.rt = undefined;
    _key_4_allKeys = [];
    // keep track of which components have finished
    intro_4Components = [];
    intro_4Components.push(intro1_4);
    intro_4Components.push(key_4);
    
    intro_4Components.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function intro_4RoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'intro_4'-------
    // get current time
    t = intro_4Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *intro1_4* updates
    if (t >= 0.5 && intro1_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      intro1_4.tStart = t;  // (not accounting for frame time here)
      intro1_4.frameNStart = frameN;  // exact frame index
      
      intro1_4.setAutoDraw(true);
    }

    
    // *key_4* updates
    if (t >= 0.5 && key_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_4.tStart = t;  // (not accounting for frame time here)
      key_4.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_4.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_4.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_4.clearEvents(); });
    }

    if (key_4.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_4.getKeys({keyList: ['space'], waitRelease: false});
      _key_4_allKeys = _key_4_allKeys.concat(theseKeys);
      if (_key_4_allKeys.length > 0) {
        key_4.keys = _key_4_allKeys[_key_4_allKeys.length - 1].name;  // just the last key pressed
        key_4.rt = _key_4_allKeys[_key_4_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    intro_4Components.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function intro_4RoutineEnd() {
  return async function () {
    //------Ending Routine 'intro_4'-------
    intro_4Components.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('key_4.keys', key_4.keys);
    if (typeof key_4.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('key_4.rt', key_4.rt);
        routineTimer.reset();
        }
    
    key_4.stop();
    // the Routine "intro_4" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _keyboard_input_4_allKeys;
var practice_3Components;
function practice_3RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'practice_3'-------
    t = 0;
    practice_3Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    prompt_text_4.setColor(new util.Color([1, 1, 1]));
    buttontext_6.setPos([(- 0.25), (- 0.1)]);
    buttontext_7.setPos([0.25, (- 0.1)]);
    keyboard_input_4.keys = undefined;
    keyboard_input_4.rt = undefined;
    _keyboard_input_4_allKeys = [];
    // keep track of which components have finished
    practice_3Components = [];
    practice_3Components.push(prompt_text_4);
    practice_3Components.push(target_text_4);
    practice_3Components.push(button_6);
    practice_3Components.push(buttontext_6);
    practice_3Components.push(button_7);
    practice_3Components.push(buttontext_7);
    practice_3Components.push(keyboard_input_4);
    
    practice_3Components.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function practice_3RoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'practice_3'-------
    // get current time
    t = practice_3Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *prompt_text_4* updates
    if (t >= 0.5 && prompt_text_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      prompt_text_4.tStart = t;  // (not accounting for frame time here)
      prompt_text_4.frameNStart = frameN;  // exact frame index
      
      prompt_text_4.setAutoDraw(true);
    }

    
    // *target_text_4* updates
    if (t >= 0.5 && target_text_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      target_text_4.tStart = t;  // (not accounting for frame time here)
      target_text_4.frameNStart = frameN;  // exact frame index
      
      target_text_4.setAutoDraw(true);
    }

    
    // *button_6* updates
    if (t >= 0.5 && button_6.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      button_6.tStart = t;  // (not accounting for frame time here)
      button_6.frameNStart = frameN;  // exact frame index
      
      button_6.setAutoDraw(true);
    }

    
    // *buttontext_6* updates
    if (t >= 0.5 && buttontext_6.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      buttontext_6.tStart = t;  // (not accounting for frame time here)
      buttontext_6.frameNStart = frameN;  // exact frame index
      
      buttontext_6.setAutoDraw(true);
    }

    
    // *button_7* updates
    if (t >= 0.5 && button_7.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      button_7.tStart = t;  // (not accounting for frame time here)
      button_7.frameNStart = frameN;  // exact frame index
      
      button_7.setAutoDraw(true);
    }

    
    // *buttontext_7* updates
    if (t >= 0.5 && buttontext_7.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      buttontext_7.tStart = t;  // (not accounting for frame time here)
      buttontext_7.frameNStart = frameN;  // exact frame index
      
      buttontext_7.setAutoDraw(true);
    }

    
    // *keyboard_input_4* updates
    if (t >= 0.5 && keyboard_input_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      keyboard_input_4.tStart = t;  // (not accounting for frame time here)
      keyboard_input_4.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { keyboard_input_4.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { keyboard_input_4.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { keyboard_input_4.clearEvents(); });
    }

    if (keyboard_input_4.status === PsychoJS.Status.STARTED) {
      let theseKeys = keyboard_input_4.getKeys({keyList: ['left', 'right'], waitRelease: false});
      _keyboard_input_4_allKeys = _keyboard_input_4_allKeys.concat(theseKeys);
      if (_keyboard_input_4_allKeys.length > 0) {
        keyboard_input_4.keys = _keyboard_input_4_allKeys[_keyboard_input_4_allKeys.length - 1].name;  // just the last key pressed
        keyboard_input_4.rt = _keyboard_input_4_allKeys[_keyboard_input_4_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    practice_3Components.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function practice_3RoutineEnd() {
  return async function () {
    //------Ending Routine 'practice_3'-------
    practice_3Components.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('keyboard_input_4.keys', keyboard_input_4.keys);
    if (typeof keyboard_input_4.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('keyboard_input_4.rt', keyboard_input_4.rt);
        routineTimer.reset();
        }
    
    keyboard_input_4.stop();
    // the Routine "practice_3" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _key_5_allKeys;
var intro_5Components;
function intro_5RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'intro_5'-------
    t = 0;
    intro_5Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    key_5.keys = undefined;
    key_5.rt = undefined;
    _key_5_allKeys = [];
    // keep track of which components have finished
    intro_5Components = [];
    intro_5Components.push(intro_5b);
    intro_5Components.push(key_5);
    
    intro_5Components.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function intro_5RoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'intro_5'-------
    // get current time
    t = intro_5Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *intro_5b* updates
    if (t >= 0.5 && intro_5b.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      intro_5b.tStart = t;  // (not accounting for frame time here)
      intro_5b.frameNStart = frameN;  // exact frame index
      
      intro_5b.setAutoDraw(true);
    }

    
    // *key_5* updates
    if (t >= 0.5 && key_5.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_5.tStart = t;  // (not accounting for frame time here)
      key_5.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_5.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_5.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_5.clearEvents(); });
    }

    if (key_5.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_5.getKeys({keyList: ['space'], waitRelease: false});
      _key_5_allKeys = _key_5_allKeys.concat(theseKeys);
      if (_key_5_allKeys.length > 0) {
        key_5.keys = _key_5_allKeys[_key_5_allKeys.length - 1].name;  // just the last key pressed
        key_5.rt = _key_5_allKeys[_key_5_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    intro_5Components.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function intro_5RoutineEnd() {
  return async function () {
    //------Ending Routine 'intro_5'-------
    intro_5Components.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('key_5.keys', key_5.keys);
    if (typeof key_5.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('key_5.rt', key_5.rt);
        routineTimer.reset();
        }
    
    key_5.stop();
    // the Routine "intro_5" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var withinBlock;
var currentLoop;
function withinBlockLoopBegin(withinBlockLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    withinBlock = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.FULLRANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: condsFile,
      seed: undefined, name: 'withinBlock'
    });
    psychoJS.experiment.addLoop(withinBlock); // add the loop to the experiment
    currentLoop = withinBlock;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    withinBlock.forEach(function() {
      const snapshot = withinBlock.getSnapshot();
    
      withinBlockLoopScheduler.add(importConditions(snapshot));
      withinBlockLoopScheduler.add(wordRoutineBegin(snapshot));
      withinBlockLoopScheduler.add(wordRoutineEachFrame());
      withinBlockLoopScheduler.add(wordRoutineEnd());
      withinBlockLoopScheduler.add(endLoopIteration(withinBlockLoopScheduler, snapshot));
    });
    
    return Scheduler.Event.NEXT;
  }
}


async function withinBlockLoopEnd() {
  psychoJS.experiment.removeLoop(withinBlock);

  return Scheduler.Event.NEXT;
}


var targets;
var shuffledTargets;
var target1b;
var target2b;
var _keyboard_input_allKeys;
var wordComponents;
function wordRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'word'-------
    t = 0;
    wordClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    targets = [target1, target2];
    shuffledTargets = targets.sort((a, b) => 0.5 - Math.random());
    target1b = shuffledTargets[0];
    target2b = shuffledTargets[1];
    psychoJS.experiment.addData("my_button1", targets[0]);
    psychoJS.experiment.addData("my_button2", targets[1]);
    
    prompt_text.setColor(new util.Color([1, 1, 1]));
    prompt_text.setText(carrier_sentence);
    target_text.setText(target_sentence);
    buttontext_1.setPos([(- 0.25), (- 0.1)]);
    buttontext_1.setText(target1b);
    buttontext_2.setPos([0.25, (- 0.1)]);
    buttontext_2.setText(target2b);
    keyboard_input.keys = undefined;
    keyboard_input.rt = undefined;
    _keyboard_input_allKeys = [];
    // keep track of which components have finished
    wordComponents = [];
    wordComponents.push(prompt_text);
    wordComponents.push(target_text);
    wordComponents.push(button_1);
    wordComponents.push(buttontext_1);
    wordComponents.push(button_2);
    wordComponents.push(buttontext_2);
    wordComponents.push(keyboard_input);
    
    wordComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function wordRoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'word'-------
    // get current time
    t = wordClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *prompt_text* updates
    if (t >= 0.5 && prompt_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      prompt_text.tStart = t;  // (not accounting for frame time here)
      prompt_text.frameNStart = frameN;  // exact frame index
      
      prompt_text.setAutoDraw(true);
    }

    
    // *target_text* updates
    if (t >= 0.5 && target_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      target_text.tStart = t;  // (not accounting for frame time here)
      target_text.frameNStart = frameN;  // exact frame index
      
      target_text.setAutoDraw(true);
    }

    
    // *button_1* updates
    if (t >= 0.5 && button_1.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      button_1.tStart = t;  // (not accounting for frame time here)
      button_1.frameNStart = frameN;  // exact frame index
      
      button_1.setAutoDraw(true);
    }

    
    // *buttontext_1* updates
    if (t >= 0.5 && buttontext_1.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      buttontext_1.tStart = t;  // (not accounting for frame time here)
      buttontext_1.frameNStart = frameN;  // exact frame index
      
      buttontext_1.setAutoDraw(true);
    }

    
    // *button_2* updates
    if (t >= 0.5 && button_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      button_2.tStart = t;  // (not accounting for frame time here)
      button_2.frameNStart = frameN;  // exact frame index
      
      button_2.setAutoDraw(true);
    }

    
    // *buttontext_2* updates
    if (t >= 0.5 && buttontext_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      buttontext_2.tStart = t;  // (not accounting for frame time here)
      buttontext_2.frameNStart = frameN;  // exact frame index
      
      buttontext_2.setAutoDraw(true);
    }

    
    // *keyboard_input* updates
    if (t >= 0.5 && keyboard_input.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      keyboard_input.tStart = t;  // (not accounting for frame time here)
      keyboard_input.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { keyboard_input.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { keyboard_input.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { keyboard_input.clearEvents(); });
    }

    if (keyboard_input.status === PsychoJS.Status.STARTED) {
      let theseKeys = keyboard_input.getKeys({keyList: ['left', 'right'], waitRelease: false});
      _keyboard_input_allKeys = _keyboard_input_allKeys.concat(theseKeys);
      if (_keyboard_input_allKeys.length > 0) {
        keyboard_input.keys = _keyboard_input_allKeys[_keyboard_input_allKeys.length - 1].name;  // just the last key pressed
        keyboard_input.rt = _keyboard_input_allKeys[_keyboard_input_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    wordComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function wordRoutineEnd() {
  return async function () {
    //------Ending Routine 'word'-------
    wordComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('keyboard_input.keys', keyboard_input.keys);
    if (typeof keyboard_input.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('keyboard_input.rt', keyboard_input.rt);
        routineTimer.reset();
        }
    
    keyboard_input.stop();
    // the Routine "word" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var outroComponents;
function outroRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'outro'-------
    t = 0;
    outroClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(3.000000);
    // update component parameters for each repeat
    // keep track of which components have finished
    outroComponents = [];
    outroComponents.push(text);
    
    outroComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


var frameRemains;
function outroRoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'outro'-------
    // get current time
    t = outroClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *text* updates
    if (t >= 0.0 && text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text.tStart = t;  // (not accounting for frame time here)
      text.frameNStart = frameN;  // exact frame index
      
      text.setAutoDraw(true);
    }

    frameRemains = 0.0 + 3.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      text.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    outroComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function outroRoutineEnd() {
  return async function () {
    //------Ending Routine 'outro'-------
    outroComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    return Scheduler.Event.NEXT;
  };
}


function endLoopIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        const thisTrial = snapshot.getCurrentTrial();
        if (typeof thisTrial === 'undefined' || !('isTrials' in thisTrial) || thisTrial.isTrials) {
          psychoJS.experiment.nextEntry(snapshot);
        }
      }
    return Scheduler.Event.NEXT;
    }
  };
}


function importConditions(currentLoop) {
  return async function () {
    psychoJS.importAttributes(currentLoop.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}


async function quitPsychoJS(message, isCompleted) {
  // Check for and save orphaned data
  if (psychoJS.experiment.isEntryEmpty()) {
    psychoJS.experiment.nextEntry();
  }
  
  
  psychoJS.window.close();
  psychoJS.quit({message: message, isCompleted: isCompleted});
  
  return Scheduler.Event.QUIT;
}
