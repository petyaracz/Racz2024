## H-ESP

The ESP game in Hungarian.

changes log

2022-09-24 Basic version without lists plugged in.
2022-11-6 Completed version, script tested, pavlovia needs some more testing. Also this:

If you don't want participants to get stuck watching "please wait while data are uploaded to pavlovia server" you need a callback function in the pavlovia finish object and also use the jspsych-7-pavlovia-2021.12 version of the plugin. For that you need jquery. Then it works.

https://github.com/jspsych/jsPsych/discussions/2686

